#include <iostream>
#include <fstream>
#include <string>
#include <map>
using namespace std;

// Function Prototypes
void DisplayMenu();
void OptionOne(map<string, int>& frequencyData);
void OptionTwo(map<string, int>& frequencyData);
void OptionThree(map<string, int>& frequencyData);
void LoadData(map<string, int>& frequencyData);
void WriteBackupFile(const map<string, int>& frequencyData);

int main() {
    map<string, int> frequencyData; // Map to store item frequencies

    LoadData(frequencyData);        // Load data from the input file
    WriteBackupFile(frequencyData); // Create and write the backup file

    int choice = 0;
    while (choice != 4) {
        DisplayMenu();
        while (!(cin >> choice) || choice < 1 || choice > 4) { // Input validation
            cout << "Invalid input. Please enter a number between 1 and 4: ";
            cin.clear(); // Clear input buffer
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Ignore invalid input
        }

        switch (choice) {
        case 1:
            OptionOne(frequencyData);
            break;
        case 2:
            OptionTwo(frequencyData);
            break;
        case 3:
            OptionThree(frequencyData);
            break;
        case 4:
            cout << "Exiting the program. Goodbye!" << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    }

    return 0;
}

// Display menu options
void DisplayMenu() {
    cout << "\nMenu Options:" << endl;
    cout << "1. Find frequency of an item" << endl;
    cout << "2. Display frequency of all items" << endl;
    cout << "3. Display histogram of items" << endl;
    cout << "4. Exit" << endl;
    cout << "Enter your choice: ";
}

// Load data from the input file into the map
void LoadData(map<string, int>& frequencyData) {
    ifstream inputFile("CS210_Project_Three_Input_File.txt");
    string item;

    if (inputFile.is_open()) {
        while (inputFile >> item) {
            frequencyData[item]++;
        }
        inputFile.close();
    }
    else {
        cout << "Error: Unable to open input file." << endl;
    }
}

// Option One: Find the frequency of a specific item
void OptionOne(map<string, int>& frequencyData) {
    string searchItem;
    cout << "Enter the item to search for: ";
    cin >> searchItem;

    if (frequencyData.find(searchItem) != frequencyData.end()) {
        cout << "Frequency of '" << searchItem << "': " << frequencyData[searchItem] << endl;
    }
    else {
        cout << "Item '" << searchItem << "' not found." << endl;
    }
}

// Option Two: Display the frequency of all items
void OptionTwo(map<string, int>& frequencyData) {
    cout << "\nItem Frequencies:" << endl;
    for (const auto& item : frequencyData) {
        cout << item.first << ": " << item.second << endl;
    }
}

// Option Three: Display a histogram of items
void OptionThree(map<string, int>& frequencyData) {
    cout << "\nItem Histogram:" << endl;
    for (const auto& item : frequencyData) {
        cout << item.first << ": ";
        for (int i = 0; i < item.second; ++i) {
            cout << "*";
        }
        cout << endl;
    }
}

// Write data to the backup file frequency.dat
void WriteBackupFile(const map<string, int>& frequencyData) {
    ofstream outputFile("frequency.dat");

    if (outputFile.is_open()) {
        for (const auto& item : frequencyData) {
            outputFile << item.first << " " << item.second << endl;
        }
        outputFile.close();
        cout << "Backup file 'frequency.dat' created successfully." << endl;
    }
    else {
        cout << "Error: Unable to write to 'frequency.dat'." << endl;
    }
}
